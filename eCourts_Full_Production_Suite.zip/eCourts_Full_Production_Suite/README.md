# eCourts Smart Advocate Portal - Full Production Suite

## इस पैकेज में मौजूद सभी फाइलें:
1. `database/schema.sql` - PostgreSQL डेटाबेस और ऑडिट ट्रिगर्स।
2. `backend/server.js` & `package.json` - Node.js ऑटो-सिंक और CSV अपलोड API।
3. `backend/sample_cases.csv` - टेस्टिंग के लिए सैंपल CSV फाइल।
4. `flutter_app/pubspec.yaml` & `lib/main.dart` - Android और Windows PC ऐप (Freemium + Offline DB + PDF + Scanner + Notifications)।
5. `build_executables.bat` - अपने PC पर 1-क्लिक में `.exe` और `.apk` बनाने की फाइल।
6. `.github/workflows/build_apps.yml` - बिना कुछ इंस्टॉल किए GitHub Cloud पर `.exe` और `.apk` बनाने की फाइल।
