import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  runApp(const ECourtsProductionApp());
}

// ============================================================================
// 1. कॉन्फ़िगरेशन (Normal eCourts Features Free, Extra Features Pro)
// ============================================================================
class AppConfig {
  static const String apiBaseUrl = 'http://localhost:3000';
  static const double desktopBreakpoint = 800.0;
  static const String storageKeyCases = 'ecourts_prod_cases_v1';
  static const String storageKeyPremium = 'ecourts_prod_is_premium_v1';
}

// ============================================================================
// 2. लोकल पुश नोटिफिकेशन सर्विस (Offline Hearing Date Alerts)
// ============================================================================
class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidSettings);
    await _plugin.initialize(initSettings);
  }

  static Future<void> sendHearingAlert(CourtCase c) async {
    const androidDetails = AndroidNotificationDetails(
      'ecourts_hearing_channel',
      'Hearing Reminders',
      importance: Importance.max,
      priority: Priority.high,
    );
    const details = NotificationDetails(android: androidDetails);
    await _plugin.show(
      c.cnrNumber.hashCode,
      'सुनवाई की तारीख का रिमाइंडर! ⚖️',
      'CNR: ${c.cnrNumber} (${c.petitioner} vs ${c.respondent}) - अगली तारीख: ${c.nextHearingDate}',
      details,
    );
  }
}

// ============================================================================
// 3. डेटा मॉडल्स (Offline Storage JSON Serialization के साथ)
// ============================================================================
class AuditEntry {
  final String oldStatus;
  final String newStatus;
  final String timestamp;

  AuditEntry({required this.oldStatus, required this.newStatus, required this.timestamp});

  Map<String, dynamic> toJson() => {'oldStatus': oldStatus, 'newStatus': newStatus, 'timestamp': timestamp};

  factory AuditEntry.fromJson(Map<String, dynamic> json) => AuditEntry(
        oldStatus: json['oldStatus'] ?? '',
        newStatus: json['newStatus'] ?? '',
        timestamp: json['timestamp'] ?? '',
      );
}

class CourtCase {
  final String cnrNumber;
  final String caseType;
  final int caseYear;
  final String courtName;
  final String petitioner;
  final String respondent;
  final String advocateBarId;
  String status;
  String nextHearingDate;
  String judgeName;
  String courtRoomNo;
  String advocateNotes;
  List<AuditEntry> auditTrail;

  CourtCase({
    required this.cnrNumber,
    required this.caseType,
    required this.caseYear,
    required this.courtName,
    required this.petitioner,
    required this.respondent,
    required this.advocateBarId,
    required this.status,
    required this.nextHearingDate,
    required this.judgeName,
    required this.courtRoomNo,
    this.advocateNotes = '',
    List<AuditEntry>? auditTrail,
  }) : auditTrail = auditTrail ?? [];

  Map<String, dynamic> toJson() => {
        'cnrNumber': cnrNumber,
        'caseType': caseType,
        'caseYear': caseYear,
        'courtName': courtName,
        'petitioner': petitioner,
        'respondent': respondent,
        'advocateBarId': advocateBarId,
        'status': status,
        'nextHearingDate': nextHearingDate,
        'judgeName': judgeName,
        'courtRoomNo': courtRoomNo,
        'advocateNotes': advocateNotes,
        'auditTrail': auditTrail.map((a) => a.toJson()).toList(),
      };

  factory CourtCase.fromJson(Map<String, dynamic> json) => CourtCase(
        cnrNumber: json['cnrNumber'] ?? '',
        caseType: json['caseType'] ?? 'Civil Appeal',
        caseYear: json['caseYear'] ?? 2026,
        courtName: json['courtName'] ?? 'High Court',
        petitioner: json['petitioner'] ?? '',
        respondent: json['respondent'] ?? '',
        advocateBarId: json['advocateBarId'] ?? 'D/1234/2015',
        status: json['status'] ?? 'Pending',
        nextHearingDate: json['nextHearingDate'] ?? '15 Nov 2026',
        judgeName: json['judgeName'] ?? 'Justice S. Roy',
        courtRoomNo: json['courtRoomNo'] ?? 'Room 4',
        advocateNotes: json['advocateNotes'] ?? '',
        auditTrail: (json['auditTrail'] as List<dynamic>?)
                ?.map((e) => AuditEntry.fromJson(e as Map<String, dynamic>))
                .toList() ??
            [],
      );
}

// ============================================================================
// 4. ऑफलाइन लोकल डेटाबेस और सब्सक्रिप्शन मैनेजर
// ============================================================================
class LocalDatabase {
  static Future<bool> isPremium() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(AppConfig.storageKeyPremium) ?? false;
  }

  static Future<void> setPremium(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConfig.storageKeyPremium, value);
  }

  static Future<void> saveCases(List<CourtCase> cases) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        AppConfig.storageKeyCases, jsonEncode(cases.map((e) => e.toJson()).toList()));
  }

  static Future<List<CourtCase>> loadCases(String barId) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(AppConfig.storageKeyCases);
    if (raw != null && raw.isNotEmpty) {
      final List decoded = jsonDecode(raw);
      return decoded.map((e) => CourtCase.fromJson(e)).toList();
    }
    final defaults = [
      CourtCase(
        cnrNumber: 'DLHC010001232023',
        caseType: 'Civil Appeal',
        caseYear: 2023,
        courtName: 'Delhi High Court',
        petitioner: 'Ramesh Sharma',
        respondent: 'State of NCT',
        advocateBarId: barId,
        status: 'Hearing',
        nextHearingDate: '15 Nov 2026',
        judgeName: 'Justice S. Roy',
        courtRoomNo: 'Court Room 4',
        advocateNotes: 'गवाहों के बयान की कॉपी प्रस्तुत करनी है।',
      ),
      CourtCase(
        cnrNumber: 'DLHC010009872024',
        caseType: 'Criminal Petition',
        caseYear: 2024,
        courtName: 'Tis Hazari Court',
        petitioner: 'Suresh Gupta',
        respondent: 'Sunita Gupta',
        advocateBarId: barId,
        status: 'Pending',
        nextHearingDate: '01 Dec 2026',
        judgeName: 'Magistrate A. Verma',
        courtRoomNo: 'Room 202',
        advocateNotes: 'जमानत अर्जी पर बहस।',
      ),
    ];
    await saveCases(defaults);
    return defaults;
  }
}

// ============================================================================
// 5. मुख्य ऐप और रिस्पॉन्सिव वर्कस्पेस (Windows PC & Android Phone)
// ============================================================================
class ECourtsProductionApp extends StatelessWidget {
  const ECourtsProductionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'eCourts Smart Advocate Portal',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF1E1B4B),
        scaffoldBackgroundColor: const Color(0xFFF1F5F9),
      ),
      home: const ProductionWorkspace(advocateBarId: 'D/1234/2015'),
    );
  }
}

class ProductionWorkspace extends StatefulWidget {
  final String advocateBarId;
  const ProductionWorkspace({super.key, required this.advocateBarId});

  @override
  State<ProductionWorkspace> createState() => _ProductionWorkspaceState();
}

class _ProductionWorkspaceState extends State<ProductionWorkspace> {
  bool _isPremium = false;
  bool _isLoading = true;
  List<CourtCase> _cases = [];
  CourtCase? _selectedCase;
  final TextEditingController _searchCtrl = TextEditingController();
  String _statusFilter = 'All';

  @override
  void initState() {
    super.initState();
    _initData();
  }

  Future<void> _initData() async {
    final prem = await LocalDatabase.isPremium();
    final loaded = await LocalDatabase.loadCases(widget.advocateBarId);
    setState(() {
      _isPremium = prem;
      _cases = loaded;
      if (_cases.isNotEmpty) _selectedCase = _cases.first;
      _isLoading = false;
    });
  }

  List<CourtCase> get _filteredCases {
    final q = _searchCtrl.text.toLowerCase().trim();
    return _cases.where((c) {
      final matchQuery = q.isEmpty ||
          c.cnrNumber.toLowerCase().contains(q) ||
          c.petitioner.toLowerCase().contains(q) ||
          c.respondent.toLowerCase().contains(q) ||
          c.courtName.toLowerCase().contains(q);
      final matchStatus = _statusFilter == 'All' || c.status == _statusFilter;
      return matchQuery && matchStatus;
    }).toList();
  }

  // एक्स्ट्रा प्रीमियम फीचर्स के लिए Paywall
  void _showProPaywall(String extraFeatureName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.workspace_premium, color: Colors.amber, size: 28),
            SizedBox(width: 8),
            Expanded(child: Text('प्रीमियम एडवोकेट टूल (PRO)')),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('"$extraFeatureName" एक एक्स्ट्रा प्रो फीचर है।'),
            const SizedBox(height: 10),
            const Text('सामान्य eCourts फीचर्स (केस स्टेटस, असीमित केस जोड़ना, बेसिक सर्च और प्राइवेट नोट्स) हमेशा 100% FREE हैं।'),
            const SizedBox(height: 10),
            const Text(
              'एक्स्ट्रा PRO फीचर्स में शामिल हैं:
'
              '• बारकोड / QR कोड कैमरा स्कैनर
'
              '• CSV बल्क केस डायरी इम्पोर्ट
'
              '• कॉज-लिस्ट और प्राइवेट नोट्स की PDF रिपोर्ट
'
              '• वन-क्लिक ऑटो-सिंक और सुनवाई रिमाइंडर अलर्ट',
              style: TextStyle(fontSize: 13),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('रद्द करें')),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFF312E81)),
            onPressed: () async {
              await LocalDatabase.setPremium(true);
              setState(() => _isPremium = true);
              if (!context.mounted) return;
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('बधाई हो! सभी एक्स्ट्रा PRO फीचर्स अनलॉक हो गए हैं!'), backgroundColor: Colors.teal),
              );
            },
            icon: const Icon(Icons.verified),
            label: const Text('PRO अनलॉक करें (₹299/माह)'),
          ),
        ],
      ),
    );
  }

  // फ्री फीचर: नया केस जोड़ना (असीमित)
  void _addFreeCaseDialog() {
    final cnrCtrl = TextEditingController();
    final petCtrl = TextEditingController();
    final respCtrl = TextEditingController();
    final courtCtrl = TextEditingController(text: 'Delhi High Court');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('नया केस जोड़ें (100% Free Feature)'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: cnrCtrl, decoration: const InputDecoration(labelText: 'CNR नंबर')),
              TextField(controller: petCtrl, decoration: const InputDecoration(labelText: 'वादी (Petitioner)')),
              TextField(controller: respCtrl, decoration: const InputDecoration(labelText: 'प्रतिवादी (Respondent)')),
              TextField(controller: courtCtrl, decoration: const InputDecoration(labelText: 'अदालत (Court Name)')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('रद्द करें')),
          FilledButton(
            onPressed: () async {
              if (cnrCtrl.text.trim().isEmpty) return;
              final newCase = CourtCase(
                cnrNumber: cnrCtrl.text.trim().toUpperCase(),
                caseType: 'Civil Petition',
                caseYear: 2026,
                courtName: courtCtrl.text.trim(),
                petitioner: petCtrl.text.trim(),
                respondent: respCtrl.text.trim().isEmpty ? 'State' : respCtrl.text.trim(),
                advocateBarId: widget.advocateBarId,
                status: 'Pending',
                nextHearingDate: '20 Dec 2026',
                judgeName: 'Hon'ble Bench',
                courtRoomNo: 'Room 1',
              );
              setState(() {
                _cases.insert(0, newCase);
                _selectedCase = newCase;
              });
              await LocalDatabase.saveCases(_cases);
              if (!context.mounted) return;
              Navigator.pop(context);
            },
            child: const Text('सेव करें'),
          ),
        ],
      ),
    );
  }

  // PRO फीचर 1: CSV बल्क अपलोड
  Future<void> _handleProCsvUpload() async {
    if (!_isPremium) {
      _showProPaywall('CSV बल्क केस फाइल अपलोड');
      return;
    }
    FilePickerResult? res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv'],
      withData: true,
    );
    if (res == null || res.files.single.bytes == null) return;

    final content = utf8.decode(res.files.single.bytes!);
    final lines = const LineSplitter().convert(content);
    int added = 0;
    for (int i = 1; i < lines.length; i++) {
      final cols = lines[i].split(',');
      if (cols.length >= 6) {
        setState(() {
          _cases.insert(
            0,
            CourtCase(
              cnrNumber: cols[0].trim(),
              caseType: cols[1].trim(),
              caseYear: int.tryParse(cols[2].trim()) ?? 2026,
              courtName: cols[3].trim(),
              petitioner: cols[4].trim(),
              respondent: cols[5].trim(),
              advocateBarId: widget.advocateBarId,
              status: 'Pending',
              nextHearingDate: '25 Nov 2026',
              judgeName: 'Hon'ble Court',
              courtRoomNo: 'Room 2',
            ),
          );
        });
        added++;
      }
    }
    await LocalDatabase.saveCases(_cases);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('CSV से $added केस इम्पोर्ट और ऑफलाइन सेव हो गए!'), backgroundColor: Colors.teal),
    );
  }

  // PRO फीचर 2: ऑटो-सिंक केस स्टेटस
  Future<void> _handleProAutoSync() async {
    if (!_isPremium) {
      _showProPaywall('ऑटो-सिंक केस स्टेटस इंजन');
      return;
    }
    final statuses = ['Pending', 'Hearing', 'Arguments Complete', 'Disposed'];
    setState(() {
      for (var c in _cases) {
        if (c.status != 'Disposed') {
          final old = c.status;
          c.status = statuses[(statuses.indexOf(old) + 1) % statuses.length];
          c.auditTrail.insert(0, AuditEntry(oldStatus: old, newStatus: c.status, timestamp: 'Auto-Synced'));
        }
      }
    });
    await LocalDatabase.saveCases(_cases);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('सभी केसों का स्टेटस ऑटो-सिंक और सेव हो गया!'), backgroundColor: Colors.teal),
    );
  }

  // PRO फीचर 3: कॉज-लिस्ट PDF रिपोर्ट
  void _handleProPdfExport() {
    if (!_isPremium) {
      _showProPaywall('प्रोफेशनल PDF कॉज-लिस्ट एवं नोट्स एक्सपोर्ट');
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(title: const Text('Cause List & Notes PDF')),
          body: PdfPreview(
            build: (format) async {
              final pdf = pw.Document();
              pdf.addPage(
                pw.MultiPage(
                  pageFormat: format,
                  build: (ctx) => [
                    pw.Text('eCourts Advocate Cause List & Private Notes',
                        style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                    pw.SizedBox(height: 12),
                    pw.TableHelper.fromTextArray(
                      headers: ['CNR Number', 'Parties', 'Court', 'Next Date', 'Status', 'Private Notes'],
                      data: _filteredCases
                          .map((c) => [
                                c.cnrNumber,
                                '${c.petitioner} vs ${c.respondent}',
                                c.courtName,
                                c.nextHearingDate,
                                c.status,
                                c.advocateNotes,
                              ])
                          .toList(),
                    ),
                  ],
                ),
              );
              return pdf.save();
            },
          ),
        ),
      ),
    );
  }

  // PRO फीचर 4: बारकोड / QR स्कैनर
  void _handleProScanner() {
    if (!_isPremium) {
      _showProPaywall('बारकोड / QR कोड कैमरा स्कैनर');
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(title: const Text('Scan CNR Barcode / QR')),
          body: MobileScanner(
            onDetect: (capture) {
              for (final b in capture.barcodes) {
                if (b.rawValue != null) {
                  setState(() => _searchCtrl.text = b.rawValue!.trim());
                  Navigator.pop(context);
                  break;
                }
              }
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final isDesktop = constraints.maxWidth >= AppConfig.desktopBreakpoint;

        return Scaffold(
          appBar: AppBar(
            backgroundColor: const Color(0xFF1E1B4B),
            foregroundColor: Colors.white,
            title: Text(_isPremium ? 'eCourts Smart Portal (PRO 👑)' : 'eCourts Smart Portal (Free Edition)'),
            actions: [
              IconButton(onPressed: _handleProCsvUpload, tooltip: 'CSV अपलोड (PRO)', icon: const Icon(Icons.upload_file)),
              IconButton(onPressed: _handleProAutoSync, tooltip: 'ऑटो-सिंक (PRO)', icon: const Icon(Icons.sync)),
              IconButton(onPressed: _handleProPdfExport, tooltip: 'PDF रिपोर्ट (PRO)', icon: const Icon(Icons.picture_as_pdf)),
              if (!_isPremium)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: Colors.amber.shade700),
                    onPressed: () => _showProPaywall('सभी एक्स्ट्रा प्रो टूल्स'),
                    icon: const Icon(Icons.star, size: 16),
                    label: const Text('Unlock Pro'),
                  ),
                ),
            ],
          ),
          body: Row(
            children: [
              Expanded(
                flex: 5,
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _searchCtrl,
                              onChanged: (_) => setState(() {}),
                              decoration: InputDecoration(
                                hintText: 'फ्री केस सर्च (CNR, पार्टी या कोर्ट)...',
                                prefixIcon: const Icon(Icons.search),
                                filled: true,
                                fillColor: Colors.white,
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          IconButton.filled(
                            onPressed: _handleProScanner,
                            style: IconButton.styleFrom(backgroundColor: const Color(0xFF312E81)),
                            tooltip: 'बारकोड स्कैनर (PRO)',
                            icon: const Icon(Icons.qr_code_scanner, color: Colors.amber),
                          ),
                        ],
                      ),
                    ),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Row(
                        children: [
                          for (final s in ['All', 'Hearing', 'Pending', 'Disposed'])
                            Padding(
                              padding: const EdgeInsets.only(right: 8.0),
                              child: ChoiceChip(
                                label: Text(s),
                                selected: _statusFilter == s,
                                onSelected: (_) => setState(() => _statusFilter = s),
                              ),
                            ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.all(12),
                        itemCount: _filteredCases.length,
                        itemBuilder: (context, index) {
                          final item = _filteredCases[index];
                          return Card(
                            color: Colors.white,
                            margin: const EdgeInsets.only(bottom: 10),
                            child: ListTile(
                              title: Text(item.cnrNumber,
                                  style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                              subtitle: Text('${item.petitioner} vs ${item.respondent}\nअगली तारीख: ${item.nextHearingDate}'),
                              isThreeLine: true,
                              trailing: Chip(label: Text(item.status)),
                              onTap: () => setState(() => _selectedCase = item),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              if (isDesktop) const VerticalDivider(width: 1),
              if (isDesktop)
                Expanded(
                  flex: 6,
                  child: _selectedCase == null
                      ? const Center(child: Text('विवरण देखने के लिए कोई केस चुनें'))
                      : _buildCaseDetailPane(_selectedCase!),
                ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            backgroundColor: const Color(0xFF312E81),
            foregroundColor: Colors.white,
            onPressed: _addFreeCaseDialog,
            icon: const Icon(Icons.add),
            label: const Text('नया केस जोड़ें (Free)'),
          ),
        );
      },
    );
  }

  Widget _buildCaseDetailPane(CourtCase c) {
    final notesCtrl = TextEditingController(text: c.advocateNotes);

    return SingleChildScrollView(
      key: ValueKey(c.cnrNumber),
      padding: const EdgeInsets.all(20),
      child: Card(
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('CNR: ${c.cnrNumber}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 8),
              Text('${c.petitioner} vs ${c.respondent}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text('${c.courtName} • ${c.courtRoomNo} • ${c.judgeName} • अगली सुनवाई: ${c.nextHearingDate}'),
              const Divider(height: 28),
              const Text('प्राइवेट एडवोकेट केस नोट्स (Offline Saved):', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextField(
                controller: notesCtrl,
                maxLines: 4,
                decoration: const InputDecoration(border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 10,
                children: [
                  FilledButton.icon(
                    onPressed: () async {
                      c.advocateNotes = notesCtrl.text.trim();
                      await LocalDatabase.saveCases(_cases);
                      if (!mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('नोट्स ऑफलाइन डेटाबेस में सेव हो गए!')),
                      );
                    },
                    icon: const Icon(Icons.save),
                    label: const Text('नोट्स सेव करें (Free)'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () {
                      if (!_isPremium) {
                        _showProPaywall('लोकल पुश नोटिफिकेशन रिमाइंडर अलर्ट');
                        return;
                      }
                      NotificationService.sendHearingAlert(c);
                    },
                    icon: const Icon(Icons.notifications_active),
                    label: const Text('तारीख रिमाइंडर अलर्ट (PRO)'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
