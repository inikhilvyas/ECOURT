const express = require('express');
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const cron = require('node-cron');
const { Pool } = require('pg');

const app = express();
app.use(express.json());

// एडजस्टेबल डेटाबेस कनेक्शन सेटिंग्स
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'ecourts_db',
  password: 'your_password',
  port: 5432,
});

const upload = multer({ dest: 'uploads/' });

// 1. एडवोकेट लॉगिन एंडपॉइंट
app.post('/api/advocate/login', async (req, res) => {
  const { barRegistrationNumber, password } = req.body;
  if (!barRegistrationNumber || !password) {
    return res.status(400).json({ success: false, message: 'Bar ID और पासवर्ड आवश्यक हैं।' });
  }
  return res.json({
    success: true,
    message: 'लॉगिन सफल रहा!',
    advocateProfile: { barRegistrationNumber }
  });
});

// 2. एडवोकेट द्वारा CSV फाइल अपलोड करके केस अपडेट करना
app.post('/api/advocate/upload-cases', upload.single('caseFile'), async (req, res) => {
  const advocateBarId = req.body.barId;
  const filePath = req.file?.path;
  if (!filePath || !advocateBarId) {
    return res.status(400).json({ success: false, message: 'फाइल और Bar ID आवश्यक हैं।' });
  }

  const casesToInsert = [];
  fs.createReadStream(filePath)
    .pipe(csv())
    .on('data', (row) => casesToInsert.push(row))
    .on('end', async () => {
      fs.unlinkSync(filePath);
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        for (const item of casesToInsert) {
          const query = `
            INSERT INTO cases (cnr_number, case_type, case_year, court_name, petitioner_name, respondent_name, advocate_bar_id, case_status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, 'Pending')
            ON CONFLICT (cnr_number) DO UPDATE SET
              court_name = EXCLUDED.court_name,
              advocate_bar_id = EXCLUDED.advocate_bar_id,
              updated_at = CURRENT_TIMESTAMP;
          `;
          await client.query(query, [
            item.cnr_number, item.case_type, parseInt(item.case_year || 2026),
            item.court_name, item.petitioner_name, item.respondent_name, advocateBarId
          ]);
        }
        await client.query('COMMIT');
        res.json({ success: true, message: `${casesToInsert.length} केस सफलतापूर्वक अपलोड/अपडेट हो गए।` });
      } catch (e) {
        await client.query('ROLLBACK');
        res.status(500).json({ success: false, message: e.message });
      } finally {
        client.release();
      }
    });
});

// 3. ऑटो-सिंक केस स्टेटस इंजन
async function syncAllPendingCases() {
  const statuses = ['Hearing', 'Arguments Complete', 'Disposed', 'Pending'];
  try {
    const { rows } = await pool.query("SELECT cnr_number FROM cases WHERE case_status != 'Disposed'");
    for (const r of rows) {
      const nextStatus = statuses[Math.floor(Math.random() * statuses.length)];
      await pool.query('UPDATE cases SET case_status = $1 WHERE cnr_number = $2', [nextStatus, r.cnr_number]);
    }
  } catch (err) {
    console.error('Auto-sync error:', err.message);
  }
}

cron.schedule('0 0 * * *', () => syncAllPendingCases());

app.post('/api/cases/trigger-sync', async (req, res) => {
  await syncAllPendingCases();
  res.json({ success: true, message: 'ऑटो-सिंक प्रक्रिया पूरी हो गई।' });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`eCourts Backend running on http://localhost:${PORT}`));
