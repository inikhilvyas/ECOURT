@echo off
SET PROJECT_FOLDER=flutter_app
SET OUTPUT_DIST_FOLDER=Ready_To_Install_Files

echo [1/4] Initializing Flutter platform folders (Android & Windows)...
cd %PROJECT_FOLDER%
call flutter create --platforms=android,windows .

echo [2/4] Downloading packages...
call flutter pub get

echo [3/4] Building Windows PC Executable (.exe)...
call flutter build windows --release

echo [4/4] Building Android Mobile Installer (.apk)...
call flutter build apk --release

cd ..
mkdir %OUTPUT_DIST_FOLDER%
mkdir %OUTPUT_DIST_FOLDER%\Windows_PC_App

copy "%PROJECT_FOLDER%\build\app\outputs\flutter-apk\app-release.apk" "%OUTPUT_DIST_FOLDER%\eCourts_Advocate_Pro.apk"
xcopy "%PROJECT_FOLDER%\build\windows\x64\runner\Release\*" "%OUTPUT_DIST_FOLDER%\Windows_PC_App\" /E /I /Y

echo Done! Check the '%OUTPUT_DIST_FOLDER%' folder for your .apk and .exe files.
pause
