-- eCourts Production Database Schema (PostgreSQL)
CREATE TABLE IF NOT EXISTS advocates (
    bar_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15),
    is_premium BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cases (
    cnr_number VARCHAR(16) PRIMARY KEY,
    case_type VARCHAR(50) NOT NULL,
    case_year INT NOT NULL,
    court_name VARCHAR(150) NOT NULL,
    petitioner_name VARCHAR(150) NOT NULL,
    respondent_name VARCHAR(150) NOT NULL,
    advocate_bar_id VARCHAR(50) REFERENCES advocates(bar_id),
    case_status VARCHAR(30) DEFAULT 'Pending',
    next_hearing_date VARCHAR(30) DEFAULT '15 Nov 2026',
    advocate_notes TEXT DEFAULT '',
    search_vector tsvector,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- सुपर-फास्ट फुल-टेक्स्ट सर्च के लिए GIN इंडेक्स
CREATE INDEX IF NOT EXISTS idx_cases_search_vector ON cases USING GIN(search_vector);

CREATE OR REPLACE FUNCTION update_cases_search_vector()
RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector :=
        setweight(to_tsvector('english', COALESCE(NEW.cnr_number, '')), 'A') ||
        setweight(to_tsvector('english', COALESCE(NEW.petitioner_name, '')), 'B') ||
        setweight(to_tsvector('english', COALESCE(NEW.respondent_name, '')), 'B') ||
        setweight(to_tsvector('english', COALESCE(NEW.court_name, '')), 'C');
    NEW.updated_at := CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_update_search_vector ON cases;
CREATE TRIGGER trg_update_search_vector
BEFORE INSERT OR UPDATE ON cases
FOR EACH ROW EXECUTE FUNCTION update_cases_search_vector();

-- ऑटोमैटिक ऑडिट लॉग टेबल और ट्रिगर
CREATE TABLE IF NOT EXISTS case_history_audit (
    audit_id SERIAL PRIMARY KEY,
    cnr_number VARCHAR(16),
    old_status VARCHAR(30),
    new_status VARCHAR(30),
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    action_type VARCHAR(20)
);

CREATE OR REPLACE FUNCTION log_case_status_changes()
RETURNS TRIGGER AS $$
BEGIN
    IF (OLD.case_status IS DISTINCT FROM NEW.case_status) THEN
        INSERT INTO case_history_audit (cnr_number, old_status, new_status, action_type)
        VALUES (NEW.cnr_number, OLD.case_status, NEW.case_status, 'STATUS_UPDATE');
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_audit_case_changes ON cases;
CREATE TRIGGER trg_audit_case_changes
AFTER UPDATE ON cases
FOR EACH ROW EXECUTE FUNCTION log_case_status_changes();
